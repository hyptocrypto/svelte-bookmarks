
module.exports = {
    content: ['./public/**/*.html', './src/**/*.{svelte,js}'],
    theme: {
        extend: {},
    },
    plugins: [],
};

